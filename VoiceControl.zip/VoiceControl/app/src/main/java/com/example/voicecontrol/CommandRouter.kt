package com.example.voicecontrol

import android.content.Context
import android.media.AudioManager
import android.view.KeyEvent

/** Turns a spoken sentence into an action. Fast local rules first, the AI (Claude) for everything else. */
object CommandRouter {

    @Volatile var dictating = false

    private fun rx(p: String) = Regex(p, RegexOption.IGNORE_CASE)

    fun handle(ctx: Context, raw: String, speakRaw: (String) -> Unit) {
        val name = Prefs.userName(ctx)
        val ack = "حاضر أستاذ $name"
        val speak: (String) -> Unit = { m -> speakRaw(if (m == "تم") ack else m) }
        val t = Normalizer.norm(raw)
        val svc = PhoneControlService.instance

        fun need(block: (PhoneControlService) -> Unit) {
            if (svc == null) speak("فعّل خدمة إمكانية الوصول أولاً") else block(svc)
        }
        fun ok(b: Boolean, done: String = "تم", fail: String = "لم أستطع") = speak(if (b) done else fail)
        fun any(vararg k: String) = k.any { t == Normalizer.norm(it) }
        fun starts(vararg k: String) = k.any { t.startsWith(Normalizer.norm(it)) }
        fun has(vararg k: String) = k.any { t.contains(Normalizer.norm(it)) }

        // ---------- dictation mode: everything you say is typed ----------
        if (dictating) {
            when {
                any("انتهيت", "خلصت", "توقف عن الكتابه", "وقف الكتابه", "stop typing", "done") -> {
                    dictating = false; speak("تمام أستاذ $name، أنهيت الكتابة")
                }
                any("ارسل", "ارسال", "send") -> need { ok(it.pressEnter()) }
                any("امسح", "امسح الكل", "clear") -> need { ok(it.clearText()) }
                else -> need { if (!it.appendText(raw)) speak("لا يوجد حقل نص مفتوح") }
            }
            return
        }

        when {
            // ---- control of the listener itself ----
            any("توقف عن الاستماع", "وقف الاستماع", "stop listening") -> {
                speak("حسناً أستاذ $name، أوقفت الاستماع"); VoiceService.stop(ctx)
            }

            // ---- dictation ----
            any("ابدا الكتابه", "وضع الكتابه", "املي", "اكتب بالصوت", "start typing", "dictate") -> {
                dictating = true
                speak("حاضر أستاذ $name، تفضل أنا أكتب ما تقوله. قل انتهيت عند الانتهاء")
            }

            // ---- navigation ----
            any("ارجع", "رجوع", "للخلف", "back", "go back") -> need { ok(it.back()) }
            any("الرئيسيه", "الشاشه الرئيسيه", "روح للرئيسيه", "home", "go home") -> need { ok(it.home()) }
            any("التطبيقات الاخيره", "التطبيقات المفتوحه", "recent apps", "recents") -> need { ok(it.recents()) }
            any("الاشعارات", "افتح الاشعارات", "notifications") -> need { ok(it.notifications()) }
            any("الاعدادات السريعه", "quick settings") -> need { ok(it.quickSettings()) }
            any("لقطه شاشه", "صور الشاشه", "خذ لقطه", "screenshot") -> need { ok(it.screenshot()) }
            has("اطفي الشاشه", "اطفئ الشاشه", "سكر الشاشه", "اقفل الشاشه", "قفل الشاشه", "lock screen", "screen off", "turn off the screen") ->
                need { ok(it.lockScreen()) }
            any("قائمه الطاقه", "اطفاء الهاتف", "power menu") -> need { ok(it.powerMenu()) }
            any("شغل الشاشه", "صحي الشاشه", "نور الشاشه", "wake screen") -> { Actions.wakeScreen(ctx); speak("تم") }

            // ---- scrolling / swiping ----
            starts("انزل", "نزل", "مرر لتحت", "مرر للاسفل", "scroll down", "لتحت", "تحت") -> need { it.scroll(true); speak("تم") }
            starts("اطلع", "ارفع الشاشه", "مرر لفوق", "مرر للاعلي", "مرر للاعلى", "scroll up", "لفوق", "فوق") -> need { it.scroll(false); speak("تم") }
            starts("اسحب يمين", "swipe right") -> need { it.swipeSide(false); speak("تم") }
            starts("اسحب يسار", "swipe left") -> need { it.swipeSide(true); speak("تم") }

            // ---- keyboard ----
            any("ارسل", "ارسال", "انتر", "enter", "send", "بحث", "search") -> need { ok(it.pressEnter()) }

            // ---- reading ----
            any("اقرا الشاشه", "اقراء الشاشه", "اقرا الصفحه", "read screen", "read the page") -> need {
                val s = it.readableText(); speak(if (s.isBlank()) "لا يوجد نص ظاهر" else s)
            }

            // ---- information that needs no internet ----
            any("كم الساعه", "الساعه كم", "الوقت", "what time is it", "time") ->
                speak(java.text.SimpleDateFormat("h:mm a", java.util.Locale("ar")).format(java.util.Date()))
            any("ما التاريخ", "اي يوم اليوم", "التاريخ", "what is the date", "date") ->
                speak(java.text.SimpleDateFormat("EEEE d MMMM yyyy", java.util.Locale("ar")).format(java.util.Date()))
            any("كم البطاريه", "نسبه البطاريه", "البطاريه", "battery") -> {
                val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as android.os.BatteryManager
                speak("البطارية ${bm.getIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CAPACITY)} بالمئة")
            }
            has("واي فاي", "wifi", "wi-fi", "وايفاي") && has("شغل", "اطفي", "افتح", "فعل", "turn", "open") ->
                ok(Actions.launch(ctx, android.content.Intent(android.provider.Settings.ACTION_WIFI_SETTINGS)))
            has("بلوتوث", "bluetooth") && has("شغل", "اطفي", "افتح", "فعل", "turn", "open") ->
                ok(Actions.launch(ctx, android.content.Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS)))

            // ---- browser ----
            any("تصفح", "افتح المتصفح", "المتصفح", "browser") -> ok(Actions.openBrowser(ctx))

            // ---- hardware ----
            rx("^(?:شغل|افتح|اضيء|اضئ|turn on)\\s+(?:الكشاف|الفلاش|المصباح|flashlight|torch)").containsMatchIn(t) ->
                ok(Actions.torch(ctx, true))
            rx("^(?:اطفي|اطفئ|سكر|اغلق|turn off)\\s+(?:الكشاف|الفلاش|المصباح|flashlight|torch)").containsMatchIn(t) ->
                ok(Actions.torch(ctx, false))
            starts("ارفع الصوت", "زود الصوت", "volume up", "louder") -> { Actions.volume(ctx, AudioManager.ADJUST_RAISE); speak("تم") }
            starts("اخفض الصوت", "وطي الصوت", "نقص الصوت", "volume down", "quieter") -> { Actions.volume(ctx, AudioManager.ADJUST_LOWER); speak("تم") }
            starts("كتم الصوت", "mute") -> { Actions.volume(ctx, AudioManager.ADJUST_MUTE); speak("تم") }
            any("وقف الموسيقى", "ايقاف مؤقت", "pause", "pause music") -> { Actions.mediaKey(ctx, KeyEvent.KEYCODE_MEDIA_PAUSE); speak("تم") }
            any("شغل الموسيقى", "كمل الموسيقى", "play", "play music", "resume") -> { Actions.mediaKey(ctx, KeyEvent.KEYCODE_MEDIA_PLAY); speak("تم") }
            any("التالي", "الاغنيه التاليه", "next", "next song") -> { Actions.mediaKey(ctx, KeyEvent.KEYCODE_MEDIA_NEXT); speak("تم") }
            any("السابق", "الاغنيه السابقه", "previous", "previous song") -> { Actions.mediaKey(ctx, KeyEvent.KEYCODE_MEDIA_PREVIOUS); speak("تم") }

            else -> handleWithArgs(ctx, raw, t, svc, speak)
        }
    }

    private fun handleWithArgs(
        ctx: Context, raw: String, t: String, svc: PhoneControlService?, speak: (String) -> Unit
    ) {
        fun ok(b: Boolean, done: String = "تم", fail: String = "لم أستطع") = speak(if (b) done else fail)

        // type text (raw text keeps the original spelling)
        rx("^\\s*(?:اكتب|type|write)\\s+(.+)").find(raw)?.let { m ->
            if (svc == null) return speak("فعّل خدمة إمكانية الوصول أولاً")
            return ok(svc.appendText(m.groupValues[1].trim()), "تم", "لا يوجد حقل نص مفتوح")
        }
        if (rx("^(?:امسح النص|امسح الكتابه|clear text)$").containsMatchIn(t)) {
            return ok(svc?.clearText() == true)
        }
        rx("^(?:اضغط(?: علي| على)?|انقر(?: علي| على)?|اختار|click(?: on)?|tap(?: on)?|press)\\s+(.+)").find(t)?.let { m ->
            if (svc == null) return speak("فعّل خدمة إمكانية الوصول أولاً")
            return ok(svc.clickText(m.groupValues[1]), "تم", "لم أجد ${m.groupValues[1]}")
        }
        rx("^(?:افتح موقع|افتح الموقع|روح الي موقع|روح الي|اذهب الي|تصفح|go to|browse|open website)\\s+(.+)").find(t)?.let { m ->
            return ok(Actions.openUrl(ctx, m.groupValues[1]))
        }
        rx("^(?:ابحث عن|دور على|دور علي|search for|search|google)\\s+(.+)").find(t)?.let { m ->
            return ok(Actions.webSearch(ctx, m.groupValues[1]))
        }
        rx("^(?:اتصل ب|اتصل بـ|كلم|call|phone)\\s+(.+)").find(t)?.let { m ->
            return ok(Actions.call(ctx, m.groupValues[1]), "أتصل الآن", "لم أجد الرقم")
        }
        rx("(\\d+)\\s*(?:دقيقه|دقايق|دقائق|دقيقة|minutes?|mins?)").find(t)?.let { m ->
            if (t.contains("مؤقت") || t.contains("timer") || t.contains("منبه"))
                return ok(Actions.setTimer(ctx, m.groupValues[1].toInt()), "ضبطت المؤقت")
        }
        rx("^(?:افتح|شغل تطبيق|شغل|open|launch|start)\\s+(.+)").find(t)?.let { m ->
            if (Actions.openApp(ctx, m.groupValues[1])) return speak("تم")
            // not an installed app name → fall through to the AI
        }

        // everything else: talk with Claude (questions, chat, complex phone tasks)
        if (Prefs.apiKey(ctx).isNotBlank()) {
            AgentClient.run(ctx, raw, speak)
        } else {
            speak("لم أفهم: $raw. أضف مفتاح Gemini المجاني في التطبيق لأتحدث معك وأفهم أي أمر")
        }
    }
}
