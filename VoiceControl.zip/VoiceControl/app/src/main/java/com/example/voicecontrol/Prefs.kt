package com.example.voicecontrol

import android.content.Context

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("vc", Context.MODE_PRIVATE)

    fun apiKey(c: Context) = sp(c).getString("apiKey", "") ?: ""
    fun wakeWord(c: Context) = sp(c).getString("wake", "يا هاتف") ?: "يا هاتف"
    fun requireWake(c: Context) = sp(c).getBoolean("requireWake", true)
    fun userName(c: Context) = sp(c).getString("name", "محمدو") ?: "محمدو"
    fun lang(c: Context) = sp(c).getString("lang", "ar-SA") ?: "ar-SA"
    fun provider(c: Context) = sp(c).getString("provider", "gemini") ?: "gemini"
    fun model(c: Context) = if (provider(c) == "gemini") "gemini-2.5-flash" else "claude-sonnet-5-5"

    fun save(c: Context, apiKey: String, wake: String, requireWake: Boolean, lang: String, name: String, provider: String) {
        sp(c).edit()
            .putString("apiKey", apiKey.trim())
            .putString("wake", wake.trim())
            .putBoolean("requireWake", requireWake)
            .putString("lang", lang)
            .putString("provider", provider)
            .putString("name", name.trim().ifEmpty { "محمدو" })
            .apply()
    }
}
