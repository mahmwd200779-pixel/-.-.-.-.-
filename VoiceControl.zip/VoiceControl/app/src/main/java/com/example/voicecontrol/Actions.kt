package com.example.voicecontrol

import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.PowerManager
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.view.KeyEvent

/** Phone-level actions that don't need to touch the screen. */
object Actions {

    private val aliases = mapOf(
        "يوتيوب" to "youtube", "واتساب" to "whatsapp", "واتس اب" to "whatsapp", "كاميرا" to "camera",
        "الكاميرا" to "camera", "اعدادات" to "settings", "الاعدادات" to "settings", "كروم" to "chrome",
        "خرائط" to "maps", "الخرائط" to "maps", "تيليجرام" to "telegram", "تلجرام" to "telegram",
        "انستقرام" to "instagram", "انستغرام" to "instagram", "فيسبوك" to "facebook", "سناب" to "snapchat",
        "سناب شات" to "snapchat", "تيك توك" to "tiktok", "الهاتف" to "phone", "اتصال" to "phone",
        "الرسائل" to "messages", "الساعه" to "clock", "الحاسبه" to "calculator", "المعرض" to "photos",
        "الصور" to "photos", "جيميل" to "gmail", "سبوتيفاي" to "spotify", "نتفلكس" to "netflix",
        "جوجل" to "google", "قوقل" to "google", "المتجر" to "play store", "بلاي ستور" to "play store"
    )

    /** Starts an activity even when called from a background service (uses the accessibility service context). */
    fun launch(ctx: Context, intent: Intent): Boolean {
        val c: Context = PhoneControlService.instance ?: ctx
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try { c.startActivity(intent); true } catch (e: Exception) { false }
    }

    /** Consonant skeleton so "الكامرة" / "كاميرا" / "الكاميره" all compare equal. */
    private fun skeleton(s: String): String =
        Normalizer.norm(s).removePrefix("ال").replace(Regex("[اويه ]"), "")

    fun openApp(ctx: Context, spoken: String): Boolean {
        val pm = ctx.packageManager
        val q = Normalizer.norm(spoken)
        val alias = aliases[q] ?: aliases[q.removePrefix("ال")] ?: aliases["ال$q"]
        val apps = pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0
        )
        fun label(i: android.content.pm.ResolveInfo) = Normalizer.norm(i.loadLabel(pm).toString())
        fun pkg(i: android.content.pm.ResolveInfo) = i.activityInfo.packageName.lowercase()
        val sk = skeleton(q)
        val match = apps.firstOrNull { label(it) == q || (alias != null && label(it) == alias) }
            ?: apps.firstOrNull { sk.length >= 2 && skeleton(label(it)) == sk }
            ?: apps.firstOrNull { alias != null && (label(it).contains(alias) || pkg(it).contains(alias.replace(" ", ""))) }
            ?: apps.firstOrNull { q.length >= 2 && label(it).contains(q) }
            ?: apps.firstOrNull { label(it).length > 2 && q.contains(label(it)) }
            ?: return false
        val intent = pm.getLaunchIntentForPackage(match.activityInfo.packageName) ?: return false
        return launch(ctx, intent)
    }

    fun findNumber(ctx: Context, name: String): String? {
        if (name.all { it.isDigit() || it == '+' || it == ' ' }) return name.replace(" ", "")
        return try {
            ctx.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
                "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
                arrayOf("%$name%"), null
            )?.use { if (it.moveToFirst()) it.getString(0) else null }
        } catch (e: SecurityException) { null }
    }

    fun call(ctx: Context, who: String): Boolean {
        val num = findNumber(ctx, who) ?: return false
        return launch(ctx, Intent(Intent.ACTION_CALL, Uri.parse("tel:$num")))
    }

    private val sites = mapOf(
        "يوتيوب" to "youtube.com", "جوجل" to "google.com", "قوقل" to "google.com",
        "فيسبوك" to "facebook.com", "تويتر" to "x.com", "ويكيبيديا" to "wikipedia.org",
        "انستقرام" to "instagram.com", "واتساب" to "web.whatsapp.com", "نتفلكس" to "netflix.com"
    )

    fun openBrowser(ctx: Context) = launch(
        ctx, Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_BROWSER)
    )

    /** Opens a website if the text looks like one, otherwise searches the web for it. */
    fun openUrl(ctx: Context, target: String): Boolean {
        val t = target.trim().replace(" ", "")
        val url = when {
            t.contains(".") -> if (t.startsWith("http")) t else "https://$t"
            sites[Normalizer.norm(target)] != null -> "https://" + sites[Normalizer.norm(target)]
            else -> null
        }
        return if (url != null) launch(ctx, Intent(Intent.ACTION_VIEW, Uri.parse(url))) else webSearch(ctx, target)
    }

    fun webSearch(ctx: Context, q: String) =
        launch(ctx, Intent(Intent.ACTION_WEB_SEARCH).putExtra("query", q))

    fun setTimer(ctx: Context, minutes: Int) = launch(
        ctx, Intent(AlarmClock.ACTION_SET_TIMER)
            .putExtra(AlarmClock.EXTRA_LENGTH, minutes * 60)
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
    )

    fun torch(ctx: Context, on: Boolean): Boolean = try {
        val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.first { cm.getCameraCharacteristics(it)
            .get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
        cm.setTorchMode(id, on); true
    } catch (e: Exception) { false }

    fun volume(ctx: Context, dir: Int) {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.adjustStreamVolume(AudioManager.STREAM_MUSIC, dir, AudioManager.FLAG_SHOW_UI)
    }

    fun mediaKey(ctx: Context, code: Int) {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    @Suppress("DEPRECATION")
    fun wakeScreen(ctx: Context) {
        val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
        pm.newWakeLock(
            PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP,
            "voicecontrol:wake"
        ).acquire(5000)
    }
}
