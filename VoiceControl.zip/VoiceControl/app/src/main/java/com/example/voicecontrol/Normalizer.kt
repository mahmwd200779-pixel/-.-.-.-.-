package com.example.voicecontrol

object Normalizer {
    /** Lowercase, strip Arabic diacritics, unify letter forms, convert Arabic digits to 0-9. */
    fun norm(s: String): String {
        val sb = StringBuilder()
        for (ch in s.lowercase()) {
            when (ch) {
                'أ', 'إ', 'آ' -> sb.append('ا')
                'ى' -> sb.append('ي')
                'ة' -> sb.append('ه')
                'ـ' -> {}
                in '\u064B'..'\u0652' -> {}
                in '\u0660'..'\u0669' -> sb.append('0' + (ch - '\u0660'))
                else -> sb.append(ch)
            }
        }
        return sb.toString().replace(Regex("\\s+"), " ").trim()
    }
}
