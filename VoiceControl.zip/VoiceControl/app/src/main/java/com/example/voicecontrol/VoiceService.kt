package com.example.voicecontrol

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/** Always-on foreground service: listens continuously, runs commands, talks back. */
class VoiceService : Service() {

    companion object {
        @Volatile var running = false
        fun start(c: Context) {
            val i = Intent(c, VoiceService::class.java)
            if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i) else c.startService(i)
        }
        fun stop(c: Context) { c.stopService(Intent(c, VoiceService::class.java)) }
    }

    private val main = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    @Volatile private var speaking = false
    private var lock: PowerManager.WakeLock? = null
    @Volatile private var conversationUntil = 0L
    private fun extendConversation(ms: Long = 25000) { conversationUntil = System.currentTimeMillis() + ms }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        val ch = "vc_listen"
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(ch, "الاستماع", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, ch)
            .setContentTitle("التحكم الصوتي يعمل")
            .setContentText("أنا أستمع لأوامرك")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .build()
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(1, n)

        lock = (getSystemService(POWER_SERVICE) as PowerManager)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "voicecontrol:listen").apply { acquire() }

        tts = TextToSpeech(this) { st ->
            if (st == TextToSpeech.SUCCESS) {
                tts?.language = Locale.forLanguageTag(Prefs.lang(this))
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(id: String?) {}
                    override fun onDone(id: String?) { speaking = false; extendConversation(20000) }
                    @Deprecated("") override fun onError(id: String?) { speaking = false }
                })
                ttsReady = true
            }
        }
        listen()
    }

    private fun speak(text: String) {
        if (!ttsReady) return
        speaking = true
        recognizer?.cancel()
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "u")
    }

    private fun listen(delay: Long = 300) {
        main.postDelayed({
            if (!running) return@postDelayed
            if (speaking) { listen(500); return@postDelayed }
            recognizer?.destroy()
            recognizer = SpeechRecognizer.createSpeechRecognizer(this).also { it.setRecognitionListener(listener) }
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, Prefs.lang(this@VoiceService))
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
                putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
            }
            recognizer?.startListening(i)
        }, delay)
    }

    private val listener = object : RecognitionListener {
        override fun onResults(results: Bundle?) {
            val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (!text.isNullOrBlank()) process(text)
            listen()
        }
        override fun onError(error: Int) {
            listen(if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1500 else 400)
        }
        override fun onReadyForSpeech(p: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    private fun process(raw: String) {
        var cmd = raw.trim()
        val name = Prefs.userName(this)
        val inConversation = System.currentTimeMillis() < conversationUntil || CommandRouter.dictating
        if (Prefs.requireWake(this)) {
            val w = Prefs.wakeWord(this)
            val idx = cmd.indexOf(w, ignoreCase = true)
            if (idx in 0..8) cmd = cmd.substring(idx + w.length).trim()
            else if (!inConversation) return        // not for us
            if (cmd.isEmpty()) { extendConversation(); speak("نعم أستاذ $name؟"); return }
        }
        extendConversation()
        CommandRouter.handle(this, cmd) { speak(it) }
    }

    override fun onDestroy() {
        running = false
        main.removeCallbacksAndMessages(null)
        recognizer?.destroy()
        tts?.shutdown()
        lock?.let { if (it.isHeld) it.release() }
        super.onDestroy()
    }
}
